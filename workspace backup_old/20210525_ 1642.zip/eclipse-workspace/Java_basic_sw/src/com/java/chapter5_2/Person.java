package com.java.chapter5_2;

public class Person {
	String name;		//이름
	int height;			//키
	double weight;		//몸무게
	char gender;  		//성별
	boolean married;	//결혼여부
}
