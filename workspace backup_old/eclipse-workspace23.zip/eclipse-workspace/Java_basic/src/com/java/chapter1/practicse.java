package com.java.chapter1;

public class practicse {

}
