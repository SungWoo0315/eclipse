package chapter3;

public class test {

	public static void main(String[] args) {
		//책 72p
		
		int num = 10;
		
		System.out.println(+num);
		System.out.println(-num);
		System.out.println(num);
		
		num = -num;
		System.out.println(num);

		//byte
		byte b = 1;
		System.out.println(b);
		System.out.println(-b);
		
		b = -1;
		System.out.println(b);
	}

}
