package com.java.homework;

public class test_tset_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int hol = 1;
		
		System.out.print((hol+2)%10 + " ");
		
	}
	
}
