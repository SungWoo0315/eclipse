package com.java.ex_ing;

public class Student {
	String name;
	String address;
	int age;
	int grade;
	
	Score[] subj;
	
//	Score subj1;
//	Score subj2;
}
