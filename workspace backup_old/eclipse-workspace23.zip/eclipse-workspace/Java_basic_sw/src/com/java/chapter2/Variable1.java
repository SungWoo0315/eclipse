package com.java.chapter2;

public class Variable1 {

	public static void main(String[] args) {
		// type : primitive type, object type(class)
		
		int level;			//정수형 변수 level을 선언
		level = 10;			//level 변수에 값 10을 대입
							//숫자 리터럴
		
		
		System.out.println(level);	//level 값 출력

		System.out.println("Hello, Java"); //"Hello, Java" <---객체이다.
		
		//primitive type 을 다 제외하고 숫자이다.
		
//52p 참고
//		String str = "Hello, java";    //문자 리터럴
//		String str = new String("Hello, java")  // new operator
		
		//위의 두가지랑 System.out.println("Hello, Java");은 같은것 ( 61p 리터럴형 )
		//원래는 new가 들어가야 하지만 ...  (45~46p)
		

		/* 2. 변수이름 사용
		int q_level;
		int count100;
		int _master;
		int $won;
		
		int !won;
		
		int 27day;
		int 1abc;
		
		int package;
		int new;
		int class;
		*/ //주석처리를 해제하고 이클립스에서 보면 에러 이유를 확인 할 수 있다.
		
		
		// 의미있는 변수 선업!
		
		/*int ns;					// 학생수
		int numberOfStudent;	// 학생수
		
		int studentIsGraduated; // 졸업여부?
		*/
		
		//소문자로 시작 다음문장 시작 접속어 앞부분은 대문자. ->> 카멜 표기법.
		
	}

}
