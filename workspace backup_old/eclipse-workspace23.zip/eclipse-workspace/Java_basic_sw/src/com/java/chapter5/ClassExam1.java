package com.java.chapter5;

public class ClassExam1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
