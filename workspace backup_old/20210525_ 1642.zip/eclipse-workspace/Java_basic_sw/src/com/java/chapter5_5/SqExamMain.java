package com.java.chapter5_5;

public class SqExamMain {

	public static void main(String[] args) {


		SqExam sq = new SqExam("홍길동");
		SqExam sq2 = new SqExam(20, 30);
		SqExam sq3 = new SqExam("홍길동", 40, 50);

	}

}
