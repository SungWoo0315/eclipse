package kosmo;

public class MyStudent {

	public static void main(String[] args) {
		System.out.println("kosmo �л��Դϴ�");
	}
}

