package ex.java.input;

public class Quiz1 {

	public static void main(String[] args) {
		int a = Integer.parseInt(args[0]);
		int b = Integer.parseInt(args[1]);
		int c = Integer.parseInt(args[2]);
		
		System.out.println("sum : " + (a + b + c));
		System.out.println("arv : " + ((a + b + c)/3));
		
	}

}
