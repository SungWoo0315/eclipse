package hello;

public class HelloMain {

	public static void main(String[] args) {
		System.out.println("Hello, Java");
		System.out.println("안녕, 자바!");		
		System.out.println("123+123");
		System.out.println("ddd");
	}

}
