package hello;

public class MyName {

}
