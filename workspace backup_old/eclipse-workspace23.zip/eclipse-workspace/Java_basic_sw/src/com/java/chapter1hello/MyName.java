package com.java.chapter1hello;

public class MyName {

}
