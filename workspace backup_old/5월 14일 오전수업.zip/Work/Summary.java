package kosmo;

public class Summary {
	// To do
}