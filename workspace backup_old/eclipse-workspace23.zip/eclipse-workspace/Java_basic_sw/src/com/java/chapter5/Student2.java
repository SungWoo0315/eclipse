package com.java.chapter5;

public class Student2 {	
// class 지시자 : 클래스의 코드를 정의하는 곳!
	
	
	// 멤버필드 (변수, 식별자) : 속성
	// 속성은 어디에 위치해도 상관없다.
	String address;
	String studentName;
	int grade;	
	int studentId; 
	
	// 과목별 점수: 과목+점수
	//Score2 subj; //해당과목
	
//	Score2 subj1; //수학
//	Score2 subj2; //국어
	
	Score2[] subj; //수학, 국어....
	
	// 멤버 메서드 : 함수
	
	
}