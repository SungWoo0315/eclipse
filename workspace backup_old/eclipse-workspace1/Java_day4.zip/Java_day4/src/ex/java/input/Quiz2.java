package ex.java.input;

public class Quiz2 {

	public static void main(String[] args) {
		int a = Integer.parseInt(args[0]);
		int b = Integer.parseInt(args[1]);
				
		System.out.println(a + 100);
		System.out.println(b % 10);
	
	}
}