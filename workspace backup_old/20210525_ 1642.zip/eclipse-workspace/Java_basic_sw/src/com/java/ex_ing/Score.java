package com.java.ex_ing;

public class Score {
	String subject;
	int score;
}
