package com.java.chapter5;

public class Person {
	
		// 멤버 필드(변수)
		String name;	//이름
		int height;		//키
		double weight;	//몸무게
		char gender; 	//성별
		//boolean sex; // true: 남자, false: 여자.
		//byte s; //s: 0 남자, s: 1 여자, 나머지 x
		boolean married; //결혼여부
		
		
		// 다른클래스가 참조(관계)를 많이하면 따로 파일을 만들어주는것이 좋다.
}
