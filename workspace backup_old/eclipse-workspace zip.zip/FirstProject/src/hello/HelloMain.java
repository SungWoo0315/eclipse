package hello;

public class HelloMain {

	public static void main(String[] args) {
		System.out.println("Hello, Java");
		System.out.println("�ȳ�, �ڹ�!");		
	}

}
