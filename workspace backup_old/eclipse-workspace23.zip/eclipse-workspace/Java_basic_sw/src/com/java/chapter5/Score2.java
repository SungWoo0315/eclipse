package com.java.chapter5;

public class Score2 {
		// 과목 + 점수
	String subject; // 과목
	int score;		// 점수
}
