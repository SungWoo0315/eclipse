package com.java.chapter5;

public class Student {	
// class 지시자 : 클래스의 코드를 정의하는 곳!
	
	
	// 멤버필드 (변수, 식별자) : 속성
	// 속성은 어디에 위치해도 상관없다.
	String address;
	String studentName;
	int grade;	
	int studentId; 
	
	// 멤버 메서드 : 함수
	
	
}